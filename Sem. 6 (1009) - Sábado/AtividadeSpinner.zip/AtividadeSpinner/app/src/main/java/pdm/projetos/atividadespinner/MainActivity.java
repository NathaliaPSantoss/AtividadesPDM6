package pdm.projetos.atividadespinner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    Spinner spnTempo;
    TextView tvDicas;
    ArrayList<String> dicasFDS;
    Dicas aux;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewsById();

        dicasFDS = new ArrayList<>();
        aux = new Dicas();
    }

    private void findViewsById() {
        spnTempo = findViewById(R.id.spn_clima);
        tvDicas = findViewById(R.id.tv_dicas);
    }

    public void verDicas(View view){
        String aux2 = "";
        String clima = spnTempo.getSelectedItem().toString();

        switch (clima){
            case "Chuvoso":
                dicasFDS = aux.sugereDicas("Chuvoso");

                break;
            case "Ensolarado":
                dicasFDS = aux.sugereDicas("Ensolarado");

                break;
            case "Tempestade":
                dicasFDS = aux.sugereDicas("Tempestade");

                break;
            default:
                Toast.makeText(MainActivity.this, "Selecione uma previsão!", Toast.LENGTH_SHORT).show();
                break;
        }
        for (int i = 0; i < dicasFDS.size(); i++) {
            aux2 += dicasFDS.get(i) + "\n";
        }
            tvDicas.setText(aux2);

    }
}