package com.example.calculadora;

import android.widget.TextView;

public class Calculadora {
        int aux, aux1;
        String resultado="";
        TextView tv_resultado;

        public String multiplicacao(Integer a1, Integer a2) {
                aux = 0;
                resultado="";
                for (aux1 = 0; aux1 < a2; aux1++) {
                        resultado = resultado + aux + " + " + a1;
                        aux = aux + a1;
                        resultado = resultado + " = " + aux + "\n";
                }
                return (resultado);
        }

        public String divisao(Integer a1, Integer a2) {
                aux = 0;
                resultado="";
                if (a2 > a1){
                        resultado = "" + aux;
                        return resultado;
                } else{
                        resultado = resultado + a1 + " / " + a2 + "\n";
                        for (aux1= 0; a1 >= a2; aux1++) {
                                resultado = resultado + a1 + " - " + a2 + "\n";
                                a1 = a1 - a2;
                                aux++;
                        }
                        resultado = resultado + " = " + aux + "\n";
                        return (resultado);
                }

        }

        public String exponenciacao(Integer a1, Integer a2) {
                aux1= a1;
                resultado="";
                for (aux = 1; aux < a2; aux++) {
                        resultado = resultado + a1 + " X " + aux1;
                        a1 *= aux1;
                        resultado = resultado + " = " + a1 + "\n";
                }
                return (resultado);
        }
}
