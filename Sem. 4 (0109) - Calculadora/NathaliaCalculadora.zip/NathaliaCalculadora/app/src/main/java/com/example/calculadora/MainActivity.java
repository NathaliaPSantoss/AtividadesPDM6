package com.example.calculadora;

import static java.lang.Integer.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText et_a1, et_a2;
    TextView tv_resultado;
    Calculadora calc;
    int calculo;
    String resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calc = new Calculadora();
        et_a1 = (EditText) findViewById(R.id.a1);
        et_a2 = (EditText) findViewById(R.id.a2);
        tv_resultado = findViewById(R.id.resultado);
    }

    public void calculadora(View calculadora) {
        Integer a1 = parseInt(et_a1.getText().toString());
        Integer a2 = parseInt(et_a2.getText().toString());
        resultado="";


        if (a1 == null || a2 == null)
            tv_resultado.setText("Campos vazios! Preencha os campos!");

        switch (calculadora.getId()) {
            case R.id.limpar:
                tv_resultado = (TextView) findViewById(R.id.resultado);
                resultado="";
                et_a1.setText("");
                et_a2.setText("");
                break;
            case R.id.soma:
                calculo = a1 + a2;
                resultado = resultado + a1 + " + " + a2 + " = " +  calculo;
                break;
            case R.id.subtracao:
                calculo = a1 - a2;
                resultado = resultado + a1 + " - " + a2 + " = " + calculo;
                break;
            case R.id.multiplicacao:
                resultado = a1 + " x " + a2 + "\n" + "===================\n";
                resultado = resultado + calc.multiplicacao(a1, a2);
                break;
            case R.id.divisao:
                if (a2 == 0){
                    resultado = "Não existe divisão por 0!";
                } else {
                    resultado = a1 + " / " + a2 + "\n" + "===================\n\n";
                    resultado = resultado + calc.divisao(a1, a2);
                }
                break;
            case R.id.exponenciacao:
                resultado = a1 + " ^ " + a2 + "\n" + "===================\n";
                resultado = resultado + calc.exponenciacao(a1, a2);
                break;
            case R.id.raiz:
                resultado = " √ " + a1 + "\n" + "===================\n";
                a1 = parseInt(et_a1.getText().toString());
                et_a2.setText("2");
                calculo = (int) Math.sqrt(a1);
                resultado = resultado + String.valueOf(calculo);
                break;

        }
        tv_resultado.setText(resultado);

    }

}